SCREENSHOT SUBMISSION CHECKLIST

Capture genuine screenshots after running the app locally or deploying it:
1. Home page
2. Dataset page showing successful CSV validation
3. Data Analysis page showing at least three charts
4. Prediction page with a submitted example and displayed output
5. Dashboard page showing KPIs and review queue
6. System Design page showing requirements, use-case diagram, and workflow
7. Five sample prediction outcomes (or capture the five rows in sample_data/five_sample_predictions.csv)

No screenshots are prefilled because the app was not launched in a browser in this environment; do not submit fabricated screenshots as live evidence.
